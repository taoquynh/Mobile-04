//
//  WaterViewController.swift
//  DemoTimer
//
//  Created by Taof on 1/18/20.
//  Copyright © 2020 Taof. All rights reserved.
//

import UIKit

class WaterViewController: ViewController {

    @IBOutlet weak var waterView: UIView!
    
    @IBOutlet weak var countLabel: UILabel!
    
    var time: Timer!
    var count: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        time = Timer.scheduledTimer(timeInterval: 1,
                                     target: self,
                                     selector: #selector(runLoop),
                                     userInfo: nil,
                                     repeats: true)
    }
    
    @objc func runLoop(){
        count += 10
        waterView.frame.origin.y = CGFloat(count)
    }

}
